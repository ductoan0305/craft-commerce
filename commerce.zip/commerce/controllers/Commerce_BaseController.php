<?php
namespace Craft;

/**
 * The Base Controller for all Commerce Commerce Controllers
 *
 * @author    Make with Morph. <support@makewithmorph.com>
 * @copyright Copyright (c) 2015, Luke Holder.
 * @license   http://makewithmorph.com/commerce/license Commerce License Agreement
 * @see       http://makewithmorph.com
 * @package   craft.plugins.commerce.controllers
 * @since     0.1
 */
abstract class Commerce_BaseController extends BaseController
{

}