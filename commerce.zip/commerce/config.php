<?php
return [
    'cartCookieDuration' => 'P3M',
    'paymentMethodSettings' => [],
    'purgeInactiveCartsDuration' => 'P3M'
];